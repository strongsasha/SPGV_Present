import org.lwjgl.opengl.GL;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class RestMiror {

    static float camX = 3.5f, camY = 1.5f, camZ = -1.5f;
    static float yaw = -1.2f;
    static float pitch = -0.35f;

    static boolean wDown, sDown, aDown, dDown;
    static boolean mousePressed = false;
    static double lastMouseX, lastMouseY;

    public static void main(String[] args) {
        glfwInit();
        glfwWindowHint(GLFW_STENCIL_BITS, 8);
        long window = glfwCreateWindow(700, 500, "", 0, 0);
        glfwSetWindowPos(window, 50, 200);
        glfwMakeContextCurrent(window);
        GL.createCapabilities();

        glfwSwapInterval(1);
        glEnable(GL_DEPTH_TEST);

        glfwSetKeyCallback(window, (win, key, scancode, action, mods) -> {
            boolean isDown = (action != GLFW_RELEASE);
            if (key == GLFW_KEY_W) wDown = isDown;
            if (key == GLFW_KEY_S) sDown = isDown;
            if (key == GLFW_KEY_A) aDown = isDown;
            if (key == GLFW_KEY_D) dDown = isDown;
        });

        glfwSetMouseButtonCallback(window, (win, button, action, mods) -> {
            if (button == GLFW_MOUSE_BUTTON_1) {
                mousePressed = (action == GLFW_PRESS);
            }
        });

        glfwSetCursorPosCallback(window, (win, xpos, ypos) -> {
            if (mousePressed) {
                double dx = xpos - lastMouseX;
                double dy = ypos - lastMouseY;

                yaw += (float) (dx * 0.005);
                pitch -= (float) (dy * 0.005);

                if (pitch > 1.5f) pitch = 1.5f;
                if (pitch < -1.5f) pitch = -1.5f;
            }
            lastMouseX = xpos;
            lastMouseY = ypos;
        });

        while (!glfwWindowShouldClose(window)) {
            float dirX = (float) (Math.cos(pitch) * Math.sin(yaw));
            float dirY = (float) Math.sin(pitch);
            float dirZ = (float) -(Math.cos(pitch) * Math.cos(yaw));

            float rightX = (float) Math.sin(yaw - Math.PI / 2);
            float rightZ = (float) -(Math.cos(yaw - Math.PI / 2));

            float speed = 0.05f;
            if (wDown) { camX += dirX * speed; camY += dirY * speed; camZ += dirZ * speed; }
            if (sDown) { camX -= dirX * speed; camY -= dirY * speed; camZ -= dirZ * speed; }
            if (aDown) { camX += rightX * speed; camZ += rightZ * speed; }
            if (dDown) { camX -= rightX * speed; camZ -= rightZ * speed; }

            glClearColor(0.45f, 0.45f, 0.48f, 1);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glFrustum(-0.7, 0.7, -0.5, 0.5, 1.0, 30.0);

            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();

            lookAt(
                    camX, camY, camZ,
                    camX + dirX, camY + dirY, camZ + dirZ,
                    0.0f, 1.0f, 0.0f
            );

            drawFloor();

            drawSphere(0.8f, 0f, -3f, 0.7f, 0.9f, 0.2f, 0.2f);

            glEnable(GL_STENCIL_TEST);
            glStencilFunc(GL_ALWAYS, 1, 0xFF);
            glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
            glColorMask(false, false, false, false);
            glDepthMask(false);
            glBegin(GL_QUADS);
            glVertex3f(-1.5f, -1.7f, -1.0f);
            glVertex3f(-1.5f,  2.3f, -1.0f);
            glVertex3f(-1.5f,  2.3f, -5.0f);
            glVertex3f(-1.5f, -1.7f, -5.0f);
            glEnd();
            glColorMask(true, true, true, true);
            glDepthMask(true);

            glStencilFunc(GL_EQUAL, 1, 0xFF);
            glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
            glPushMatrix();
            glScalef(-1f, 1f, 1f);
            glCullFace(GL_FRONT);
            glEnable(GL_CULL_FACE);
            drawSphere(0.8f, 0f, -3f, 0.7f, 0.9f, 0.2f, 0.2f);
            drawFloor();
            glDisable(GL_CULL_FACE);
            glPopMatrix();
            glDisable(GL_STENCIL_TEST);

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glBegin(GL_QUADS);
            glColor4f(0.7f, 0.75f, 0.8f, 0.35f);
            glVertex3f(-1.5f, -1.7f, -1.0f);
            glVertex3f(-1.5f,  2.3f, -1.0f);
            glVertex3f(-1.5f,  2.3f, -5.0f);
            glVertex3f(-1.5f, -1.7f, -5.0f);
            glEnd();
            glDisable(GL_BLEND);

            glLineWidth(4f);
            glBegin(GL_LINE_LOOP);
            glColor3f(0.7f, 0.55f, 0.2f);
            glVertex3f(-1.49f, -1.7f, -1.0f);
            glVertex3f(-1.49f,  2.3f, -1.0f);
            glVertex3f(-1.49f,  2.3f, -5.0f);
            glVertex3f(-1.49f, -1.7f, -5.0f);
            glEnd();

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(false);
            glBegin(GL_TRIANGLE_FAN);
            glColor4f(0, 0, 0, 0.6f);
            glVertex3f(0.8f, -1.19f, -3.3f);
            for (int i = 0; i <= 30; i++) {
                double a = 2 * Math.PI * i / 30;
                glVertex3f(0.8f + (float) Math.cos(a) * 0.55f, -1.19f, -3.3f + (float) Math.sin(a) * 0.25f);
            }
            glEnd();
            glDepthMask(true);
            glDisable(GL_BLEND);

            glfwSwapBuffers(window);
            glfwPollEvents();
        }
        glfwTerminate();
    }

    static void lookAt(float ex, float ey, float ez, float cx, float cy, float cz, float ux, float uy, float uz) {
        float[] f = norm3(new float[]{cx - ex, cy - ey, cz - ez});
        float[] u = new float[]{ux, uy, uz};
        float[] s = norm3(cross3(f, u));
        float[] u2 = cross3(s, f);
        float[] m = {
                s[0], u2[0], -f[0], 0,
                s[1], u2[1], -f[1], 0,
                s[2], u2[2], -f[2], 0,
                -(s[0] * ex + s[1] * ey + s[2] * ez),
                -(u2[0] * ex + u2[1] * ey + u2[2] * ez),
                (f[0] * ex + f[1] * ey + f[2] * ez), 1
        };
        glMultMatrixf(m);
    }

    static float[] cross3(float[] a, float[] b) {
        return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    static float[] norm3(float[] a) {
        float l = (float) Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        return new float[]{a[0] / l, a[1] / l, a[2] / l};
    }

    static void drawFloor() {
        glBegin(GL_QUADS);
        for (int x = -10; x < 10; x++) {
            for (int z = -10; z < 10; z++) {
                boolean w = (x + z) % 2 == 0;
                glColor3f(w ? 0.85f : 0.25f, w ? 0.85f : 0.25f, w ? 0.85f : 0.25f);
                float s = 0.8f;
                glVertex3f(x * s, -1.2f, z * s);
                glVertex3f((x + 1) * s, -1.2f, z * s);
                glVertex3f((x + 1) * s, -1.2f, (z + 1) * s);
                glVertex3f(x * s, -1.2f, (z + 1) * s);
            }
        }
        glEnd();
    }

    static void drawSphere(float x, float y, float z, float r, float cr, float cg, float cb) {
        int st = 24, sl = 24;
        glPushMatrix();
        glTranslatef(x, y, z);
        double[] L = new double[]{0.3, 1.0, 0.5};
        double ll = Math.sqrt(L[0] * L[0] + L[1] * L[1] + L[2] * L[2]);
        L[0] /= ll; L[1] /= ll; L[2] /= ll;
        for (int i = 0; i < st; i++) {
            double lat0 = Math.PI * (-0.5 + (double) i / st);
            double lat1 = Math.PI * (-0.5 + (double) (i + 1) / st);
            double z0 = Math.sin(lat0), z1 = Math.sin(lat1);
            double zr0 = Math.cos(lat0), zr1 = Math.cos(lat1);
            glBegin(GL_QUAD_STRIP);
            for (int j = 0; j <= sl; j++) {
                double lng = 2 * Math.PI * j / sl;
                double nx = Math.cos(lng), ny = Math.sin(lng);
                double d0 = Math.max(0, nx * zr0 * L[0] + ny * zr0 * L[1] + z0 * L[2]);
                double d1 = Math.max(0, nx * zr1 * L[0] + ny * zr1 * L[1] + z1 * L[2]);
                glColor3f((float) (cr * (0.1 + d0 * 0.9)), (float) (cg * (0.1 + d0 * 0.9)), (float) (cb * (0.1 + d0 * 0.9)));
                glVertex3f((float) (nx * zr0 * r), (float) (ny * zr0 * r), (float) (z0 * r));
                glColor3f((float) (cr * (0.1 + d1 * 0.9)), (float) (cg * (0.1 + d1 * 0.9)), (float) (cb * (0.1 + d1 * 0.9)));
                glVertex3f((float) (nx * zr1 * r), (float) (ny * zr1 * r), (float) (z1 * r));
            }
            glEnd();
        }
        glPopMatrix();
    }
}