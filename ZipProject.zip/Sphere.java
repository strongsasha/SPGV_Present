import org.lwjgl.opengl.GL;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class Sphere {

    static float rotX = 20f;
    static float rotY = 30f;
    static int detail = 4;
    static boolean showWire = true;
    static double lastKey = 0;
    static int triCount = 0;

    public static void main(String[] args) {
        glfwInit();
        long window = glfwCreateWindow(700, 500, "", 0, 0);
        glfwSetWindowPos(window, 50, 200);
        glfwMakeContextCurrent(window);
        GL.createCapabilities();
        glEnable(GL_DEPTH_TEST);

        while (!glfwWindowShouldClose(window)) {
            double now = glfwGetTime();

            if (glfwGetKey(window, GLFW_KEY_LEFT)  == GLFW_PRESS) rotY -= 1.5f;
            if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) rotY += 1.5f;
            if (glfwGetKey(window, GLFW_KEY_UP)    == GLFW_PRESS) rotX -= 1.5f;
            if (glfwGetKey(window, GLFW_KEY_DOWN)  == GLFW_PRESS) rotX += 1.5f;

            if (now - lastKey > 0.15) {
                if (glfwGetKey(window, GLFW_KEY_EQUAL)       == GLFW_PRESS ||
                        glfwGetKey(window, GLFW_KEY_KP_ADD)      == GLFW_PRESS) {
                    detail = Math.min(detail + 1, 48); lastKey = now;
                }
                if (glfwGetKey(window, GLFW_KEY_MINUS)       == GLFW_PRESS ||
                        glfwGetKey(window, GLFW_KEY_KP_SUBTRACT) == GLFW_PRESS) {
                    detail = Math.max(detail - 1, 2); lastKey = now;
                }
                if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
                    showWire = !showWire; lastKey = now;
                }
            }

            glClearColor(0.12f, 0.12f, 0.15f, 1f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glFrustum(-0.6, 0.6, -0.43, 0.43, 1.0, 20.0);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            glTranslatef(0f, 0f, -4f);
            glRotatef(rotX, 1f, 0f, 0f);
            glRotatef(rotY, 0f, 1f, 0f);

            drawSphere(detail);

            glfwSetWindowTitle(window,
                    "Sphere = " + triCount + " triangel  |  +/- |  W ");

            glfwSwapBuffers(window);
            glfwPollEvents();
        }
        glfwTerminate();
    }

    static void drawSphere(int d) {
        triCount = 0;
        float r = 1.2f;

        float[][] colors = {
                {0.9f, 0.2f, 0.2f},
                {1.0f, 0.5f, 0.1f},
                {1.0f, 0.9f, 0.1f},
                {0.2f, 0.85f, 0.3f},
                {0.1f, 0.7f, 0.9f},
                {0.3f, 0.3f, 0.95f},
                {0.7f, 0.2f, 0.9f},
                {0.9f, 0.2f, 0.6f},
        };

        for (int i = 0; i < d; i++) {
            double lat0 = Math.PI * (-0.5 + (double) i / d);
            double lat1 = Math.PI * (-0.5 + (double) (i + 1) / d);
            double z0 = Math.sin(lat0), z1 = Math.sin(lat1);
            double zr0 = Math.cos(lat0), zr1 = Math.cos(lat1);

            float[] c0 = colors[i % colors.length];
            float[] c1 = colors[(i + 1) % colors.length];

            glBegin(GL_TRIANGLES);
            for (int j = 0; j < d; j++) {
                double lng0 = 2 * Math.PI * j / d;
                double lng1 = 2 * Math.PI * (j + 1) / d;

                float x00 = (float)(Math.cos(lng0)*zr0*r), y00 = (float)(Math.sin(lng0)*zr0*r), f00 = (float)(z0*r);
                float x10 = (float)(Math.cos(lng0)*zr1*r), y10 = (float)(Math.sin(lng0)*zr1*r), f10 = (float)(z1*r);
                float x01 = (float)(Math.cos(lng1)*zr0*r), y01 = (float)(Math.sin(lng1)*zr0*r), f01 = (float)(z0*r);
                float x11 = (float)(Math.cos(lng1)*zr1*r), y11 = (float)(Math.sin(lng1)*zr1*r), f11 = (float)(z1*r);

                glColor3f(c0[0], c0[1], c0[2]);       glVertex3f(x00, y00, f00);
                glColor3f(c1[0], c1[1], c1[2]);       glVertex3f(x10, y10, f10);
                glColor3f(c0[0]*.8f, c0[1]*.8f, c0[2]*.8f); glVertex3f(x01, y01, f01);

                glColor3f(c0[0]*.8f, c0[1]*.8f, c0[2]*.8f); glVertex3f(x01, y01, f01);
                glColor3f(c1[0], c1[1], c1[2]);       glVertex3f(x10, y10, f10);
                glColor3f(c1[0]*.8f, c1[1]*.8f, c1[2]*.8f); glVertex3f(x11, y11, f11);

                triCount += 8;
            }
            glEnd();
        }

        if (showWire) {
            glColor3f(0f, 0f, 0f);
            glLineWidth(1.0f);
            float o = 1.003f;

            for (int i = 0; i < d; i++) {
                double lat0 = Math.PI * (-0.5 + (double) i / d);
                double lat1 = Math.PI * (-0.5 + (double) (i + 1) / d);
                double z0 = Math.sin(lat0), z1 = Math.sin(lat1);
                double zr0 = Math.cos(lat0), zr1 = Math.cos(lat1);

                for (int j = 0; j < d; j++) {
                    double lng0 = 2 * Math.PI * j / d;
                    double lng1 = 2 * Math.PI * (j + 1) / d;

                    float x00=(float)(Math.cos(lng0)*zr0*r*o), y00=(float)(Math.sin(lng0)*zr0*r*o), f00=(float)(z0*r*o);
                    float x10=(float)(Math.cos(lng0)*zr1*r*o), y10=(float)(Math.sin(lng0)*zr1*r*o), f10=(float)(z1*r*o);
                    float x01=(float)(Math.cos(lng1)*zr0*r*o), y01=(float)(Math.sin(lng1)*zr0*r*o), f01=(float)(z0*r*o);
                    float x11=(float)(Math.cos(lng1)*zr1*r*o), y11=(float)(Math.sin(lng1)*zr1*r*o), f11=(float)(z1*r*o);

                    glBegin(GL_LINE_LOOP);
                    glVertex3f(x00,y00,f00); glVertex3f(x10,y10,f10); glVertex3f(x01,y01,f01);
                    glEnd();
                    glBegin(GL_LINE_LOOP);
                    glVertex3f(x01,y01,f01); glVertex3f(x10,y10,f10); glVertex3f(x11,y11,f11);
                    glEnd();
                }
            }
        }
    }
}