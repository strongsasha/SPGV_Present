import org.lwjgl.opengl.GL;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class Main {
    public static void main(String[] args) {
        glfwInit();
        long window = glfwCreateWindow(700, 500,"", 0, 0);
        glfwSetWindowPos(window, 50, 200);
        glfwMakeContextCurrent(window);
        GL.createCapabilities();
        glEnable(GL_DEPTH_TEST);

        while (!glfwWindowShouldClose(window)) {
            glClearColor(0.45f,0.45f,0.48f,1);
            glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glFrustum(-0.7,0.7,-0.5,0.5,1.0,40.0);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();


            lookAt(3.5f,1.5f,-1.5f,  -0.3f,0f,-3f,  0,1,0);

            glBegin(GL_QUADS);
            for(int x=-10;x<10;x++){
                for(int z=-10;z<10;z++){
                    boolean w=(x+z)%2==0;
                    glColor3f(w?0.85f:0.25f,w?0.85f:0.25f,w?0.85f:0.25f);
                    float s=0.8f;
                    glVertex3f(x*s,    -1.2f,z*s);
                    glVertex3f((x+1)*s,-1.2f,z*s);
                    glVertex3f((x+1)*s,-1.2f,(z+1)*s);
                    glVertex3f(x*s,    -1.2f,(z+1)*s);
                }
            }
            glEnd();

            drawSphere(0.8f,0f,-3f,0.7f,0.9f,0.2f,0.2f);

            // zerkadlo
            glBegin(GL_QUADS);
            glColor3f(0.5f,0.52f,0.55f);

            glVertex3f(-1.5f,-1.7f,-1.0f);
            glVertex3f(-1.5f, 2.3f,-1.0f);
            glVertex3f(-1.5f, 2.3f,-5.0f);
            glVertex3f(-1.5f,-1.7f,-5.0f);




            glEnd();





            glLineWidth(4f);
            glBegin(GL_LINE_LOOP);
            glColor3f(0.7f,0.55f,0.2f);
            glVertex3f(-1.49f,-1.7f,-1.0f);
            glVertex3f(-1.49f, 2.3f,-1.0f);
            glVertex3f(-1.49f, 2.3f,-5.0f);
            glVertex3f(-1.49f,-1.7f,-5.0f);
            glEnd();

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(false);
            glBegin(GL_TRIANGLE_FAN);
            glColor4f(0,0,0,0.6f);
            glVertex3f(0.8f,-1.19f,-3.3f);
            for(int i=0;i<=30;i++){
                double a=2*Math.PI*i/30;
                glVertex3f(0.8f+(float)Math.cos(a)*0.55f,-1.19f,-3.3f+(float)Math.sin(a)*0.25f);
            }
            glEnd();
            glDepthMask(true);
            glDisable(GL_BLEND);

            glfwSwapBuffers(window);
            glfwPollEvents();
        }
        glfwTerminate();
    }

    static void lookAt(float ex,float ey,float ez,
                       float cx,float cy,float cz,
                       float ux,float uy,float uz){
        float[] f = norm3(new float[]{cx-ex,cy-ey,cz-ez});
        float[] u = new float[]{ux,uy,uz};
        float[] s = norm3(cross3(f,u));
        float[] u2= cross3(s,f);
        float[] m={
                s[0],  u2[0], -f[0], 0,
                s[1],  u2[1], -f[1], 0,
                s[2],  u2[2], -f[2], 0,
                -(s[0]*ex+s[1]*ey+s[2]*ez),
                -(u2[0]*ex+u2[1]*ey+u2[2]*ez),
                (f[0]*ex+f[1]*ey+f[2]*ez), 1
        };
        glMultMatrixf(m);
    }

    static float[] cross3(float[]a,float[]b){
        return new float[]{a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};
    }
    static float[] norm3(float[]a){
        float l=(float)Math.sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);
        return new float[]{a[0]/l,a[1]/l,a[2]/l};
    }

    static void drawSphere(float x,float y,float z,float r,float cr,float cg,float cb){
        int st=24,sl=24;
        glPushMatrix();
        glTranslatef(x,y,z);
        double[]L=new double[]{0,0.7,0.7};
        double ll=Math.sqrt(L[0]*L[0]+L[1]*L[1]+L[2]*L[2]);
        L[0]/=ll;L[1]/=ll;L[2]/=ll;
        for(int i=0;i<st;i++){
            double lat0=Math.PI*(-0.5+(double)i/st);
            double lat1=Math.PI*(-0.5+(double)(i+1)/st);
            double z0=Math.sin(lat0),z1=Math.sin(lat1);
            double zr0=Math.cos(lat0),zr1=Math.cos(lat1);
            glBegin(GL_QUAD_STRIP);
            for(int j=0;j<=sl;j++){
                double lng=2*Math.PI*j/sl;
                double nx=Math.cos(lng),ny=Math.sin(lng);
                double d0=Math.max(0,nx*zr0*L[0]+ny*zr0*L[1]+z0*L[2]);
                double d1=Math.max(0,nx*zr1*L[0]+ny*zr1*L[1]+z1*L[2]);
                glColor3f((float)(cr*(0.1+d0*0.9)),(float)(cg*(0.1+d0*0.9)),(float)(cb*(0.1+d0*0.9)));
                glVertex3f((float)(nx*zr0*r),(float)(ny*zr0*r),(float)(z0*r));
                glColor3f((float)(cr*(0.1+d1*0.9)),(float)(cg*(0.1+d1*0.9)),(float)(cb*(0.1+d1*0.9)));
                glVertex3f((float)(nx*zr1*r),(float)(ny*zr1*r),(float)(z1*r));
            }
            glEnd();
        }
        glPopMatrix();
    }
}