import org.lwjgl.opengl.GL;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class Triangle {
    public static void main(String[] args) {
        glfwInit();
        long window = glfwCreateWindow(700, 500, "", 0, 0);
        glfwSetWindowPos(window, 50, 200);
        glfwMakeContextCurrent(window);
        GL.createCapabilities();

        while (!glfwWindowShouldClose(window)) {
            glClearColor(0.15f, 0.15f, 0.18f, 1f);
            glClear(GL_COLOR_BUFFER_BIT);

            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glOrtho(-1, 1, -1, 1, -1, 1);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();


            glBegin(GL_TRIANGLES);
            glColor3f(1.0f, 0.2f, 0.2f);
            glVertex2f(0.0f,  0.7f);

            glColor3f(0.2f, 1.0f, 0.3f);
            glVertex2f(-0.7f, -0.5f);

            glColor3f(0.2f, 0.4f, 1.0f);
            glVertex2f(0.7f, -0.5f);
            glEnd();

            glfwSwapBuffers(window);
            glfwPollEvents();
        }
        glfwTerminate();
    }
}