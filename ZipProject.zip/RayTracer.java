import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.stream.IntStream;

public class RayTracer {
    static final int W = 700, H = 500, SAMPLES = 2, MAX_BOUNCES = 4;

    static double[] v(double x, double y, double z) { return new double[]{x, y, z}; }
    static double dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
    static double[] sub(double[] a, double[] b) { return v(a[0] - b[0], a[1] - b[1], a[2] - b[2]); }
    static double[] add(double[] a, double[] b) { return v(a[0] + b[0], a[1] + b[1], a[2] + b[2]); }
    static double[] mul(double[] a, double t) { return v(a[0] * t, a[1] * t, a[2] * t); }
    static double len(double[] a) { return Math.sqrt(dot(a, a)); }
    static double[] norm(double[] a) { double l = len(a); return l < 1e-10 ? v(0, 1, 0) : mul(a, 1.0 / l); }
    static double[] cross(double[] a, double[] b) {
        return v(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]);
    }

    static double[] lightPos = v(0, 5, 0);
    static double[] sphere = {0.8, 0.0, -3.0, 0.7, 0.9, 0.2, 0.2};
    static double[] mirrorCenter = v(-1.5, 0.3, -3.0);
    static double[] mirrorNormal = v(1, 0, 0);
    static double mirrorW = 7.0, mirrorH = 7.0;

    static double camX = 3.5, camY = 1.5, camZ = -1.5;
    static double yaw = -1.2;
    static double pitch = -0.35;
    static int lastMouseX, lastMouseY;
    static Thread renderThread;

    static double hitSphere(double[] s, double[] ro, double[] rd) {
        double[] c = v(s[0], s[1], s[2]); double r = s[3];
        double[] oc = sub(ro, c);
        double a = dot(rd, rd), b = 2 * dot(oc, rd), disc = b * b - 4 * a * (dot(oc, oc) - r * r);
        if (disc < 0) return -1;
        double t = (-b - Math.sqrt(disc)) / (2 * a);
        return t > 0.001 ? t : -1;
    }

    static double hitMirror(double[] ro, double[] rd) {
        double[] mn = norm(mirrorNormal);
        double denom = dot(mn, rd);
        if (Math.abs(denom) < 1e-6) return -1;
        double t = dot(sub(mirrorCenter, ro), mn) / denom;
        if (t < 0.001) return -1;
        double[] hp = add(ro, mul(rd, t));
        double[] d = sub(hp, mirrorCenter);
        double[] right = norm(cross(v(0, 1, 0), mn));
        double u = dot(d, right);
        double vv = dot(d, v(0, 1, 0));
        if (Math.abs(u) < mirrorW / 2 && Math.abs(vv) < mirrorH / 2) return t;
        return -1;
    }

    static double[] sky(double[] rd) {
        double t = 0.5 * (norm(rd)[1] + 1);
        return add(mul(v(0.8, 0.8, 0.8), 1 - t), mul(v(0.4, 0.4, 0.45), t));
    }

    static double[] floorCol(double[] hp) {
        int tx = (int) Math.floor(hp[0] * 1.25), tz = (int) Math.floor(hp[2] * 1.25);
        return (tx + tz) % 2 == 0 ? v(0.85, 0.85, 0.85) : v(0.25, 0.25, 0.25);
    }

    static double[] trace(double[] ro, double[] rd, int bounce) {
        if (bounce > MAX_BOUNCES) return sky(rd);

        double tMin = Double.MAX_VALUE;
        boolean isMirror = false, isFloor = false;

        double ts = hitSphere(sphere, ro, rd);
        if (ts > 0 && ts < tMin) { tMin = ts; isMirror = false; isFloor = false; }

        double[] floorN = v(0, 1, 0);
        double floorY = -1.2;
        double denom = dot(floorN, rd);
        if (Math.abs(denom) > 1e-6) {
            double tf = (floorY - ro[1]) / denom;
            if (tf > 0.001 && tf < tMin) { tMin = tf; isFloor = true; isMirror = false; }
        }

        double tm = hitMirror(ro, rd);
        if (tm > 0 && tm < tMin) { tMin = tm; isMirror = true; isFloor = false; }

        if (tMin == Double.MAX_VALUE) return sky(rd);

        double[] hp = add(ro, mul(rd, tMin));

        if (isMirror) {
            double[] mn = norm(mirrorNormal);
            double[] d = sub(hp, mirrorCenter);
            double[] right = norm(cross(v(0, 1, 0), mn));
            double u = dot(d, right);
            double vv = dot(d, v(0, 1, 0));
            boolean frame = Math.abs(u) > mirrorW / 2 - 0.1 || Math.abs(vv) > mirrorH / 2 - 0.1;
            if (frame) return v(0.7, 0.55, 0.2);
            double[] reflDir = norm(sub(rd, mul(mn, 2 * dot(rd, mn))));
            return trace(add(hp, mul(mn, 0.002)), reflDir, bounce + 1);
        }

        if (isFloor) {
            double[] col = floorCol(hp);
            double[] toL = norm(sub(lightPos, hp));
            boolean shadow = false;
            double st = hitSphere(sphere, add(hp, mul(v(0, 1, 0), 0.002)), toL);
            if (st > 0) shadow = true;
            double diff = Math.max(0, dot(v(0, 1, 0), toL));
            if (shadow) diff *= 0.05;
            return mul(col, 0.1 + diff * 0.9);
        }

        double[] nor = norm(sub(hp, v(sphere[0], sphere[1], sphere[2])));
        double[] col = v(sphere[4], sphere[5], sphere[6]);
        double[] toL = norm(sub(lightPos, hp));
        double diff = Math.max(0, dot(nor, toL));
        double spec = Math.pow(Math.max(0, dot(norm(sub(toL, rd)), nor)), 32);
        return add(mul(col, 0.1 + diff * 0.9), mul(v(1, 1, 1), spec * 0.4));
    }

    static int cl(double v) { return (int) Math.max(0, Math.min(255, v * 255)); }

    static void startRender(JFrame frame, JLabel label, BufferedImage img) {
        if (renderThread != null) renderThread.interrupt();

        renderThread = new Thread(() -> {
            long startTime = System.currentTimeMillis();

            double dirX = Math.cos(pitch) * Math.sin(yaw);
            double dirY = Math.sin(pitch);
            double dirZ = -Math.cos(pitch) * Math.cos(yaw);

            double[] cam = v(camX, camY, camZ);
            double[] camDir = norm(v(dirX, dirY, dirZ));
            double[] camRight = norm(cross(camDir, v(0, 1, 0)));
            double[] camUp = cross(camRight, camDir);

            IntStream.range(0, H).parallel().forEach(y -> {
                if (Thread.currentThread().isInterrupted()) return;

                for (int x = 0; x < W; x++) {
                    double rr = 0, gg = 0, bb = 0;
                    int currentSamples = SAMPLES;
                    int ss = currentSamples * currentSamples;

                    for (int s = 0; s < ss; s++) {
                        double ox = (s % currentSamples + 0.5) / currentSamples - 0.5;
                        double oy = (s / currentSamples + 0.5) / currentSamples - 0.5;
                        double u = (x + ox - W / 2.0) / W * 1.4;
                        double vv = -(y + oy - H / 2.0) / H * (1.4 * H / W);
                        double[] rd = norm(add(add(camDir, mul(camRight, u)), mul(camUp, vv)));
                        double[] c = trace(cam, rd, 0);
                        rr += c[0]; gg += c[1]; bb += c[2];
                    }
                    img.setRGB(x, y, new Color(cl(rr / ss), cl(gg / ss), cl(bb / ss)).getRGB());
                }

                if (y % 20 == 0) label.repaint();
            });

            long endTime = System.currentTimeMillis();
            frame.setTitle(" " + (endTime - startTime) + " мс");
            label.repaint();
        });
        renderThread.start();
    }

    public static void main(String[] args) {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        JFrame frame = new JFrame("RAY TRACING");
        JLabel label = new JLabel(new ImageIcon(img));
        frame.add(label);
        frame.setSize(W + 16, H + 39);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        frame.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                double speed = 0.4;
                double dirX = Math.cos(pitch) * Math.sin(yaw);
                double dirZ = -Math.cos(pitch) * Math.cos(yaw);
                double rightX = Math.sin(yaw - Math.PI / 2);
                double rightZ = -Math.cos(yaw - Math.PI / 2);

                if (e.getKeyCode() == KeyEvent.VK_W) { camX += dirX * speed; camZ += dirZ * speed; }
                if (e.getKeyCode() == KeyEvent.VK_S) { camX -= dirX * speed; camZ -= dirZ * speed; }
                if (e.getKeyCode() == KeyEvent.VK_A) { camX += rightX * speed; camZ += rightZ * speed; }
                if (e.getKeyCode() == KeyEvent.VK_D) { camX -= rightX * speed; camZ -= rightZ * speed; }

                startRender(frame, label, img);
            }
        });

        label.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastMouseX = e.getX();
                lastMouseY = e.getY();
                frame.requestFocus();
            }
        });

        label.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - lastMouseX;
                int dy = e.getY() - lastMouseY;

                yaw += dx * 0.005;
                pitch -= dy * 0.005;

                if (pitch > 1.5) pitch = 1.5;
                if (pitch < -1.5) pitch = -1.5;

                lastMouseX = e.getX();
                lastMouseY = e.getY();

                startRender(frame, label, img);
            }
        });

        startRender(frame, label, img);
        frame.requestFocus();
    }
}